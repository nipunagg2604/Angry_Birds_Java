<?xml version="1.0" encoding="UTF-8"?>
<tileset version="1.10" tiledversion="1.11.0" name="soil" tilewidth="32" tileheight="32" tilecount="220" columns="20">
 <image source="../../../Downloads/soil.png" width="666" height="375"/>
</tileset>
