<?xml version="1.0" encoding="UTF-8"?>
<tileset version="1.10" tiledversion="1.11.0" name="Mobile - Angry Birds - Poached Eggs Theme 1" tilewidth="32" tileheight="32" tilecount="2442" columns="111">
 <image source="./Mobile - Angry Birds - Poached Eggs Theme 1.png" width="3554" height="710"/>
</tileset>
